import 'package:flutter/material.dart';

class NotificationsScreen extends StatelessWidget {
 const NotificationsScreen({super.key});
 @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Notifications')), body: const Center(child: Text('Notifications — module prêt à être raccordé aux données Firestore.')));
}
